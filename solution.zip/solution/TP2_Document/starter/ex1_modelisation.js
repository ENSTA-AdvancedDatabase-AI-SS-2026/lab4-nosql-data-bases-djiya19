/**
 * TP2 - Exercice 1 : Modélisation MongoDB
 * Use Case : HealthCare DZ - Dossiers Médicaux
 */

// Se connecter à la base médicale
use("medical_db");

// ─── 1.1 : Créer la collection avec validation ────────────────────────────────
db.createCollection("patients", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["cin", "nom", "prenom", "dateNaissance", "sexe"],
      properties: {
        cin: { bsonType: "string", description: "CIN obligatoire" },
        nom: { bsonType: "string" },
        prenom: { bsonType: "string" },
        sexe: { enum: ["M", "F"] },
        dateNaissance: { bsonType: "date" },

        adresse: {
          bsonType: "object",
          properties: {
            wilaya: { bsonType: "string" },
            commune: { bsonType: "string" }
          }
        },

        groupeSanguin: { bsonType: "string" },

        antecedents: {
          bsonType: "array",
          items: { bsonType: "string" }
        },

        allergies: {
          bsonType: "array",
          items: { bsonType: "string" }
        },

        consultations: {
          bsonType: "array",
          items: {
            bsonType: "object",
            required: ["date", "diagnostic"],
            properties: {
              date: { bsonType: "date" },
              diagnostic: { bsonType: "string" },
              medecin: {
                bsonType: "object",
                properties: {
                  nom: { bsonType: "string" },
                  specialite: { bsonType: "string" }
                }
              }
            }
          }
        }
      }
    }
  }
});

// ─── Helper data ────────────────────────────────────────────────
const wilayas = ["Alger", "Oran", "Constantine", "Annaba", "Blida"];
const noms = ["Bensalem", "Khelifi", "Mansouri", "Boukhalfa", "Cherif", "Zerrouki", "Haddad"];
const prenoms = ["Ahmed", "Yacine", "Sara", "Amira", "Mohamed", "Lina", "Rania"];

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ─── 1.2 : Génération de 20 patients ────────────────────────────────
const patients = [];

for (let i = 0; i < 20; i++) {

  const consultations = [];

  const nbConsult = 2 + Math.floor(Math.random() * 4);

  for (let j = 0; j < nbConsult; j++) {
    consultations.push({
      id: UUID(),
      date: new Date(2023, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28 + 1)),
      medecin: {
        nom: "Dr. " + random(noms),
        specialite: random(["Cardiologie", "Endocrinologie", "Généraliste"])
      },
      diagnostic: random(["HTA", "Diabète", "Asthme", "Grippe"]),
      tension: {
        systolique: 120 + Math.floor(Math.random() * 40),
        diastolique: 80 + Math.floor(Math.random() * 20)
      },
      medicaments: [
        {
          nom: random(["Amlodipine", "Metformine", "Ventoline"]),
          dosage: "5mg",
          duree: "30 jours"
        }
      ],
      notes: "Suivi médical régulier"
    });
  }

  patients.push({
    cin: "CIN" + (1000 + i),
    nom: random(noms),
    prenom: random(prenoms),
    dateNaissance: new Date(1970 + Math.floor(Math.random() * 30), 0, 1),
    sexe: Math.random() > 0.5 ? "M" : "F",
    adresse: {
      wilaya: random(wilayas),
      commune: "Centre"
    },
    groupeSanguin: random(["O+", "A+", "B+", "AB+"]),
    antecedents: Math.random() > 0.5 ? ["Diabète"] : [],
    allergies: Math.random() > 0.7 ? ["Pénicilline"] : [],
    consultations: consultations
  });
}

db.patients.insertMany(patients);

// ─── 1.3 : Analyses (référencées) ────────────────────────────────
const allPatients = db.patients.find().toArray();

const analyses = [];

allPatients.forEach(p => {
  analyses.push({
    patient_id: p._id,
    date: new Date(),
    type: random(["Glycémie", "NFS", "Lipidogramme", "Créatinine", "ECG"]),
    resultats: {
      valeur: Math.random() * 2
    },
    laboratoire: "Labo Central Alger",
    valide: true
  });
});

db.analyses.insertMany(analyses);

// ─── Résultats ────────────────────────────────
print("✅ Modélisation terminée");
print("Patients insérés:", db.patients.countDocuments());
print("Analyses insérées:", db.analyses.countDocuments());
