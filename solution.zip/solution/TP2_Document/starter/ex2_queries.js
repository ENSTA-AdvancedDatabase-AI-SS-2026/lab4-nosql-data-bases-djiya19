use("medical_db");

print("=== EX2 : Requêtes de base ===");

// ─── 2.1 Diabétiques > 50 ans à Alger ─────────────────────────────
const ex21 = db.patients.find({
  "adresse.wilaya": "Alger",
  antecedents: "Diabète type 2",
  dateNaissance: { $lte: new Date("1976-01-01") }
}).toArray();

print("\n2.1 Résultat:");
printjson(ex21);


// ─── 2.2 Allergie Pénicilline + ≥ 3 consultations ─────────────────
const ex22 = db.patients.find({
  allergies: "Pénicilline",
  $expr: { $gte: [{ $size: "$consultations" }, 3] }
}).toArray();

print("\n2.2 Résultat:");
printjson(ex22);


// ─── 2.3 Projection : dernière consultation ────────────────────────
const ex23 = db.patients.find({}, {
  nom: 1,
  prenom: 1,
  "consultations": { $slice: -1 }
}).toArray();

print("\n2.3 Résultat:");
printjson(ex23);


// ─── 2.4 Patients sans antécédents + tension > 140 ────────────────
const ex24 = db.patients.find({
  antecedents: { $size: 0 },
  "consultations.tension.systolique": { $gt: 140 }
}).toArray();

print("\n2.4 Résultat:");
printjson(ex24);


// ─── 2.5 Recherche textuelle diagnostics ───────────────────────────
const ex25 = db.patients.find({
  $text: { $search: "HTA diabète asthme" }
}).toArray();

print("\n2.5 Résultat:");
printjson(ex25);
