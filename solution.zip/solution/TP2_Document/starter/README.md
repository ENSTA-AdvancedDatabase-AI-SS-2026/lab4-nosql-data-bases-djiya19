# RAPPORT.md — TP2 MongoDB : HealthCare DZ

## Étudiant
- Nom : ACHEUK Djida
- Module : NoSQL Databases
- TP : MongoDB — HealthCare DZ

---

# 1. Justification du choix Embedding vs Referencing

## Collection `patients` → Embedding

Les consultations médicales ont été intégrées directement dans le document patient.

### Exemple

```javascript
{
  nom: "Ahmed",
  consultations: [
    {
      diagnostic: "HTA",
      date: ISODate(...)
    }
  ]
}
```

###  Justification

Le choix de l’Embedding a été utilisé car les consultations sont souvent consultées avec les informations du patient.

Cette approche permet :
- un accès rapide au dossier complet,
- une seule requête MongoDB,
- de meilleures performances,
- l’absence de jointures.

Les consultations appartiennent directement au patient et ne sont pas utilisées indépendamment.

###  Limites

- Le document peut devenir volumineux.
- Les mises à jour peuvent être plus coûteuses.

---

##  Collection `analyses` → Referencing

Les analyses médicales sont stockées dans une collection séparée.

### Exemple

```javascript
{
  patient_id: ObjectId(...),
  type: "Glycémie",
  resultats: {...}
}
```

### Justification

Le choix du Referencing a été utilisé car les analyses peuvent devenir très nombreuses.

Cette approche permet :
- d’éviter des documents trop grands,
- une meilleure flexibilité,
- une optimisation mémoire,
- un archivage plus simple.

Chaque type d’analyse possède des résultats différents :
- ECG,
- Glycémie,
- NFS,
- Lipidogramme.

Les analyses sont donc chargées uniquement lorsque nécessaire.

### Limites

- Utilisation de `$lookup`
- Requêtes plus complexes

---

# 2. Résultats explain() avant/après indexation

## Requête testée

```javascript
db.patients.find({
  "adresse.wilaya": "Alger",
  antecedents: "Diabète type 2"
}).explain("executionStats")
```

---

# Tableau comparatif

| Critère | Sans Index | Avec Index |
|---|---|---|
| nReturned | 4 | 4 |
| totalDocsExamined | 20 | 4 |
| executionTimeMillis | 5 ms | 1 ms |
| Type de scan | COLLSCAN | IXSCAN |

---

# Analyse des résultats

## Avant indexation

MongoDB utilisait :

```text
COLLSCAN
```

Cela signifie que toute la collection était parcourue document par document.

Conséquences :
- temps d’exécution plus élevé,
- lectures disque importantes,
- mauvaises performances avec de gros volumes.

---

## Après indexation

Après création de l’index composé :

```javascript
db.patients.createIndex({
  "adresse.wilaya": 1,
  antecedents: 1
})
```

MongoDB utilise :

```text
IXSCAN
```

Cela permet :
- un accès direct aux documents recherchés,
- moins de lectures disque,
- une exécution plus rapide.

---

# 3. Requête la plus complexe : Explication du pipeline

## Pipeline choisi

### Médicament le plus prescrit par spécialité médicale

```javascript
db.patients.aggregate([
  { $unwind: "$consultations" },

  { $unwind: "$consultations.medicaments" },

  {
    $group: {
      _id: {
        specialite: "$consultations.medecin.specialite",
        medicament: "$consultations.medicaments.nom"
      },
      count: { $sum: 1 }
    }
  },

  { $sort: { "_id.specialite": 1, count: -1 } },

  {
    $group: {
      _id: "$_id.specialite",
      topMedicament: { $first: "$_id.medicament" },
      prescriptions: { $first: "$count" }
    }
  }
])
```

---

#  Explication étape par étape

##  Étape 1 — `$unwind consultations`

```javascript
{ $unwind: "$consultations" }
```

Chaque consultation du tableau devient un document séparé.

Cela permet de traiter chaque consultation individuellement.

---

## Étape 2 — `$unwind medicaments`

```javascript
{ $unwind: "$consultations.medicaments" }
```

Chaque médicament devient un document séparé.

Cela permet de compter précisément chaque prescription.

---

## Étape 3 — `$group`

```javascript
{
  $group: {
    _id: {
      specialite: "...",
      medicament: "..."
    },
    count: { $sum: 1 }
  }
}
```

Les données sont regroupées :
- par spécialité médicale,
- par médicament.

Le nombre total de prescriptions est calculé.

---

## Étape 4 — `$sort`

```javascript
{ $sort: { count: -1 } }
```

Les médicaments les plus prescrits apparaissent en premier.

---

## Étape 5 — Deuxième `$group`

```javascript
{
  $group: {
    _id: "$_id.specialite",
    topMedicament: { $first: "$_id.medicament" }
  }
}
```

Grâce au tri précédent, `$first` récupère le médicament le plus prescrit pour chaque spécialité.

---

# Conclusion

Ce TP a permis de mettre en pratique :
- la modélisation documentaire MongoDB,
- l’Embedding et le Referencing,
- les pipelines d’agrégation,
- les index et l’optimisation,
- les jointures avec `$lookup`.

MongoDB offre une solution flexible et performante pour la gestion des dossiers médicaux complexes.
