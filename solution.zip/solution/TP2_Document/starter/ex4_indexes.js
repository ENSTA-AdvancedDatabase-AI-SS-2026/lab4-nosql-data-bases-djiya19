/**
 * TP2 - Exercice 4 : Index et Optimisation
 */

use("medical_db");

// ─── 4.1 : Création des index ────────────────────────────────────────

// Index 1 : wilaya + antécédents (requêtes combinées fréquentes)
db.patients.createIndex({
  "adresse.wilaya": 1,
  antecedents: 1
});

// Index 2 : consultations par date (analyse temporelle)
db.patients.createIndex({
  "consultations.date": 1
});

// Index 3 : recherche full-text sur diagnostics
db.patients.createIndex({
  "consultations.diagnostic": "text"
});

// Index 4 : optimisation $lookup (jointure analyses)
db.analyses.createIndex({
  patient_id: 1
});

print("✅ Index créés avec succès");


// ─── 4.2 : Comparaison explain() ────────────────────────────────────────

const requeteTest = {
  "adresse.wilaya": "Alger",
  antecedents: "Diabète type 2"
};

print("\n=== AVANT index ===");

const avant = db.patients.find(requeteTest).explain("executionStats");

print("nReturned:", avant.executionStats.nReturned);
print("totalDocsExamined:", avant.executionStats.totalDocsExamined);
print("executionTimeMillis:", avant.executionStats.executionTimeMillis);

print("\n=== APRÈS index ===");

const apres = db.patients.find(requeteTest).explain("executionStats");

print("nReturned:", apres.executionStats.nReturned);
print("totalDocsExamined:", apres.executionStats.totalDocsExamined);
print("executionTimeMillis:", apres.executionStats.executionTimeMillis);


// ─── 4.4 : Index TTL (archivage automatique) ────────────────────────────────

// Expire les analyses après 5 ans (5 * 365 * 24 * 60 * 60 = 157680000 secondes)
db.analyses.createIndex(
  { date: 1 },
  { expireAfterSeconds: 157680000 }
);

print("Index TTL créé (analyses expirent après 5 ans)");
