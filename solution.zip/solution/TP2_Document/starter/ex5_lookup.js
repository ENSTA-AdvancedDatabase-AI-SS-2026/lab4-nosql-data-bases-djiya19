use("medical_db");

print("=== EX5 : Jointures & analyses ===");


// ─── 5.1 Dossier complet patient (JOIN patients + analyses) ───────
const dossierComplet = db.patients.aggregate([
  {
    $lookup: {
      from: "analyses",
      localField: "_id",
      foreignField: "patient_id",
      as: "analyses"
    }
  }
]).toArray();

print("\n5.1 Dossier complet:");
printjson(dossierComplet);


// ─── 5.2 Patients avec glycémie élevée (> 1.26) ───────────────────
const glycemieHaute = db.analyses.aggregate([
  {
    $match: {
      type: "Glycémie",
      "resultats.valeur": { $gt: 1.26 }
    }
  },
  {
    $lookup: {
      from: "patients",
      localField: "patient_id",
      foreignField: "_id",
      as: "patient"
    }
  },
  { $unwind: "$patient" },
  {
    $project: {
      _id: 0,
      nom: "$patient.nom",
      prenom: "$patient.prenom",
      glycemie: "$resultats.valeur"
    }
  }
]).toArray();

print("\n5.2 Glycémie élevée:");
printjson(glycemieHaute);


// ─── 5.3 Taux d'analyses anormales par wilaya ─────────────────────
const statsAnormales = db.analyses.aggregate([
  {
    $lookup: {
      from: "patients",
      localField: "patient_id",
      foreignField: "_id",
      as: "patient"
    }
  },
  { $unwind: "$patient" },

  {
    $match: {
      "resultats.valeur": { $gt: 1.26 }
    }
  },

  {
    $group: {
      _id: "$patient.adresse.wilaya",
      totalAnormales: { $sum: 1 }
    }
  },

  { $sort: { totalAnormales: -1 } }
]).toArray();

print("\n5.3 Analyses anormales par wilaya:");
printjson(statsAnormales);
