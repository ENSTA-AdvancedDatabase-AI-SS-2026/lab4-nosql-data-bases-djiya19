
# RAPPORT — TP3 Cassandra : SmartGrid DZ

## 1. Justification des Partition Keys

### Table mesures_par_capteur

PRIMARY KEY ((capteur_id, date), timestamp)

- capteur_id permet de distribuer les données entre les nœuds.
- date évite les partitions infinies.
- timestamp comme clustering key permet le tri chronologique.

### Risque de hot partition ?

Faible.

Pourquoi :
- Les données sont réparties par capteur.
- Chaque capteur possède sa propre partition quotidienne.

Sans date :
- la partition deviendrait énorme avec le temps.

---

## Table alertes_par_wilaya

PRIMARY KEY ((wilaya, date), timestamp, capteur_id)

- Les alertes sont recherchées par wilaya et par jour.
- date réduit la taille des partitions.

Risque :
- Alger peut produire beaucoup d'alertes.
- Mais acceptable grâce au partitionnement quotidien.

---

## Table agregats_horaires

PRIMARY KEY ((wilaya, date), heure)

- Optimisé pour les dashboards.
- Lecture rapide des statistiques journalières.

---

# 2. Pourquoi ALLOW FILTERING est dangereux

ALLOW FILTERING force Cassandra à scanner des partitions
complètes pour trouver les résultats.

Problèmes :
- forte consommation mémoire
- temps de réponse élevés
- saturation du cluster
- performances imprévisibles

Exemple dangereux :

SELECT * FROM mesures_par_capteur
WHERE tension > 240
ALLOW FILTERING;

Cassandra doit lire énormément de données avant filtrage.

Bonne pratique :
Créer une table dédiée à chaque requête importante.

---

# 3. Comparaison TWCS vs STCS vs LCS

## TWCS — TimeWindowCompactionStrategy

Utilisation :
- séries temporelles
- données avec TTL
- logs IoT

Avantages :
- excellente gestion des expirations
- réduit les coûts de compaction
- idéal pour Cassandra IoT

Inconvénients :
- moins bon pour les updates fréquents

---

## STCS — SizeTieredCompactionStrategy

Utilisation :
- stratégie par défaut
- workloads généraux

Avantages :
- simple
- bonne performance d'écriture

Inconvénients :
- lecture moins performante
- amplification disque

---

## LCS — LeveledCompactionStrategy

Utilisation :
- applications avec beaucoup de lectures

Avantages :
- lectures très rapides
- faible read amplification

Inconvénients :
- écritures plus coûteuses
- compactions fréquentes

---

# Conclusion

Pour SmartGrid DZ :

- TWCS est idéal pour les mesures IoT.
- Les tables doivent être conçues selon les requêtes.
- Cassandra privilégie la scalabilité et les écritures massives.
