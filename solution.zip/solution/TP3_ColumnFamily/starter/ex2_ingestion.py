from cassandra.cluster import Cluster
from cassandra.query import BatchStatement
from cassandra import ConsistencyLevel

from uuid import uuid4
from datetime import datetime, timedelta
import random
import time

# =====================================================
# Connexion Cassandra
# =====================================================

cluster = Cluster(["127.0.0.1"])
session = cluster.connect("smartgrid")

# =====================================================
# Configuration
# =====================================================

NB_CAPTEURS = 10000
NB_MINUTES = 5

WILAYAS = [
    "Alger",
    "Oran",
    "Constantine",
    "Blida",
    "Setif"
]

# =====================================================
# Préparation des requêtes
# =====================================================

insert_mesure = session.prepare("""
INSERT INTO mesures_par_capteur (
    capteur_id,
    date,
    timestamp,
    wilaya,
    tension,
    courant,
    puissance,
    consommation,
    alerte
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
USING TTL 7776000
""")

insert_alerte = session.prepare("""
INSERT INTO alertes_par_wilaya (
    wilaya,
    date,
    timestamp,
    capteur_id,
    tension,
    consommation,
    message
)
VALUES (?, ?, ?, ?, ?, ?, ?)
USING TTL 31536000
""")

# =====================================================
# Génération des capteurs
# =====================================================

capteurs = [uuid4() for _ in range(NB_CAPTEURS)]

# =====================================================
# Ingestion
# =====================================================

print("Insertion des données IoT...")

start = time.time()

batch = BatchStatement(consistency_level=ConsistencyLevel.ONE)

count = 0
alertes = 0

for minute in range(NB_MINUTES):

    current_time = datetime.now() - timedelta(minutes=minute)

    for capteur_id in capteurs:

        wilaya = random.choice(WILAYAS)

        tension = round(random.uniform(190, 250), 2)
        courant = round(random.uniform(5, 50), 2)

        puissance = round(tension * courant, 2)

        consommation = round(random.uniform(1, 20), 2)

        alerte = tension < 200 or tension > 240

        batch.add(insert_mesure, (
            capteur_id,
            current_time.date(),
            current_time,
            wilaya,
            tension,
            courant,
            puissance,
            consommation,
            alerte
        ))

        count += 1

        # 10% alertes environ
        if alerte:

            alertes += 1

            batch.add(insert_alerte, (
                wilaya,
                current_time.date(),
                current_time,
                capteur_id,
                tension,
                consommation,
                "Tension anormale détectée"
            ))

        # Exécution batch tous les 100 inserts
        if count % 100 == 0:
            session.execute(batch)
            batch.clear()

# Dernier batch
if len(batch) > 0:
    session.execute(batch)

end = time.time()

# =====================================================
# Statistiques
# =====================================================

duration = end - start
throughput = count / duration

print(f"Mesures insérées : {count}")
print(f"Alertes insérées : {alertes}")
print(f"Temps total : {duration:.2f} secondes")
print(f"Débit : {throughput:.2f} mesures/seconde")

cluster.shutdown()
