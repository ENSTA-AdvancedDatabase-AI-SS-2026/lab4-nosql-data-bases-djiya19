// ======================================================
// EX2 — Requêtes de Base (CORRIGÉ)
// ======================================================


// ─────────────────────────────────────────────
// 2.1 Amis d’un étudiant (Etu1)
// ─────────────────────────────────────────────

MATCH (a:Etudiant {id:"E1"})-[:CONNAIT]-(ami)
RETURN DISTINCT ami.id, ami.prenom;


// ─────────────────────────────────────────────
// 2.2 Amis d’amis (sans doublons ni relation directe)
// ─────────────────────────────────────────────

MATCH (a:Etudiant {id:"E1"})-[:CONNAIT*2]-(x)
WHERE NOT (a)-[:CONNAIT]-(x)
AND a <> x
RETURN DISTINCT x.id, x.prenom
LIMIT 10;


// ─────────────────────────────────────────────
// 2.3 Même cours que E2 mais inconnus
// ─────────────────────────────────────────────

MATCH (f:Etudiant {id:"E2"})-[:SUIT]->(c:Cours)<-[:SUIT]-(e:Etudiant)
WHERE NOT (f)-[:CONNAIT]-(e)
AND f <> e
RETURN DISTINCT e.id, e.prenom, c.intitule;


// ─────────────────────────────────────────────
// 2.4 Clubs les plus populaires
// ─────────────────────────────────────────────

MATCH (e:Etudiant)-[:MEMBRE_DE]->(c:Club)
RETURN c.nom AS club,
count(e) AS nb_membres
ORDER BY nb_membres DESC;


// ─────────────────────────────────────────────
// 2.5 Profil complet étudiant
// ─────────────────────────────────────────────

MATCH (e:Etudiant {id:"E1"})

OPTIONAL MATCH (e)-[:CONNAIT]-(amis)
OPTIONAL MATCH (e)-[:SUIT]->(cours)
OPTIONAL MATCH (e)-[:MAITRISE]->(skills)
OPTIONAL MATCH (e)-[:MEMBRE_DE]->(clubs)
OPTIONAL MATCH (e)-[:A_STAGE_CHEZ]->(ent)

RETURN
e.id,
collect(DISTINCT amis.prenom) AS amis,
collect(DISTINCT cours.intitule) AS cours,
collect(DISTINCT skills.nom) AS competences,
collect(DISTINCT clubs.nom) AS clubs,
collect(DISTINCT ent.nom) AS entreprises;
