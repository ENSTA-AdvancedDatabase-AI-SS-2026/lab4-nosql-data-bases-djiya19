// 4.1 tuteur
MATCH (e:Etudiant)-[:MAITRISE]->(:Competence {nom:"Python"})
RETURN e.prenom;

// 4.2 alumni
MATCH (m:Etudiant {prenom:"Ahmed"})-[:CONNAIT*1..3]-(e)-[:A_STAGE_CHEZ]->(:Entreprise {nom:"Sonatrach"})
RETURN DISTINCT e.prenom;

// 4.3 ponts
MATCH (e:Etudiant)-[:CONNAIT]-()
WITH e, count(*) AS c
WHERE c > 5
RETURN e.prenom, c;

// 4.4 temps
MATCH ()-[r:CONNAIT]->()
RETURN r.depuis, count(r);

// 4.5 similarité
MATCH (a:Etudiant {prenom:"Ahmed"})-[:SUIT]->(c)
WITH a, collect(c) AS ca
MATCH (b:Etudiant)-[:SUIT]->(c2)
WITH a,b,ca,collect(c2) AS cb
RETURN b.prenom,
gds.similarity.jaccard(ca,cb) AS sim
ORDER BY sim DESC LIMIT 5;
