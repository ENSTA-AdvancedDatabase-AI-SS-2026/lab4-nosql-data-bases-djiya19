// shortest path
MATCH p = shortestPath(
(a:Etudiant {prenom:"Ahmed"})-[:CONNAIT*..10]-(b:Etudiant {prenom:"Yasmina"})
)
RETURN [n IN nodes(p)|n.prenom];

// projection
CALL gds.graph.project('g','Etudiant','CONNAIT');

// degree
CALL gds.degree.stream('g')
YIELD nodeId,score
RETURN gds.util.asNode(nodeId).prenom, score
ORDER BY score DESC LIMIT 10;

// Louvain
CALL gds.louvain.stream('g')
YIELD nodeId,communityId
RETURN communityId, collect(gds.util.asNode(nodeId).prenom);

// recommendation
MATCH (m:Etudiant {prenom:"Ahmed"})
MATCH (s:Etudiant)
WHERE m<>s AND NOT (m)-[:CONNAIT]-(s)
OPTIONAL MATCH (m)-[:CONNAIT]-(x)-[:CONNAIT]-(s)
OPTIONAL MATCH (m)-[:SUIT]->(c)<-[:SUIT]-(s)
WITH s,
count(DISTINCT x)*3 +
count(DISTINCT c)*2 AS score
RETURN s.prenom, score
ORDER BY score DESC LIMIT 5;

// skill path
MATCH p=(c:Cours)-[:REQUIERT*]->(s:Competence {nom:"Machine Learning"})
RETURN [n IN nodes(p)|coalesce(n.intitule,n.nom)];

CALL gds.graph.drop('g');
