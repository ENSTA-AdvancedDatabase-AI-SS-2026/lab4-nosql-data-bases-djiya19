// ======================================================
// EX1 — Création du graphe UniConnect DZ
// ======================================================

// Nettoyage
MATCH (n) DETACH DELETE n;

// ─────────────────────────────────────────────
// Contraintes
// ─────────────────────────────────────────────

CREATE CONSTRAINT etudiant_id IF NOT EXISTS
FOR (e:Etudiant) REQUIRE e.id IS UNIQUE;

CREATE CONSTRAINT cours_code IF NOT EXISTS
FOR (c:Cours) REQUIRE c.code IS UNIQUE;

CREATE CONSTRAINT competence_nom IF NOT EXISTS
FOR (c:Competence) REQUIRE c.nom IS UNIQUE;

CREATE CONSTRAINT club_nom IF NOT EXISTS
FOR (c:Club) REQUIRE c.nom IS UNIQUE;

CREATE CONSTRAINT entreprise_nom IF NOT EXISTS
FOR (e:Entreprise) REQUIRE e.nom IS UNIQUE;


// ─────────────────────────────────────────────
// Compétences
// ─────────────────────────────────────────────

UNWIND [
  {nom:"Python", categorie:"Prog"},
  {nom:"Java", categorie:"Prog"},
  {nom:"SQL", categorie:"BDD"},
  {nom:"NoSQL", categorie:"BDD"},
  {nom:"Machine Learning", categorie:"IA"},
  {nom:"Deep Learning", categorie:"IA"},
  {nom:"React", categorie:"Web"},
  {nom:"Docker", categorie:"DevOps"},
  {nom:"Linux", categorie:"Sys"},
  {nom:"Réseaux", categorie:"Infra"}
] AS c
MERGE (:Competence {nom:c.nom, categorie:c.categorie});


// ─────────────────────────────────────────────
// Cours
// ─────────────────────────────────────────────

UNWIND [
  {code:"INFO401", intitule:"BDD Avancées", credits:6},
  {code:"INFO402", intitule:"IA", credits:6},
  {code:"INFO403", intitule:"Web", credits:4},
  {code:"INFO404", intitule:"Systèmes Distribués", credits:5},
  {code:"INFO405", intitule:"Cloud", credits:4}
] AS c
MERGE (:Cours {code:c.code, intitule:c.intitule, credits:c.credits});


// ─────────────────────────────────────────────
// Clubs
// ─────────────────────────────────────────────

UNWIND [
  {nom:"AI Club USTHB", universite:"USTHB"},
  {nom:"Cyber Club UMBB", universite:"UMBB"},
  {nom:"Web Club USTO", universite:"USTO"}
] AS c
MERGE (:Club {nom:c.nom, universite:c.universite});


// ─────────────────────────────────────────────
// Entreprises
// ─────────────────────────────────────────────

UNWIND [
  {nom:"Sonatrach", secteur:"Energie"},
  {nom:"CERIST", secteur:"Recherche"},
  {nom:"Ooredoo", secteur:"Telecom"}
] AS e
MERGE (:Entreprise {nom:e.nom, secteur:e.secteur});


// ─────────────────────────────────────────────
// Étudiants (50)
// ─────────────────────────────────────────────

UNWIND range(1,50) AS i
CREATE (:Etudiant {
  id:"E"+toString(i),
  prenom: "Etu"+toString(i),
  nom: "Nom"+toString(i),

  universite: CASE i%5
    WHEN 0 THEN "USTHB"
    WHEN 1 THEN "UMBB"
    WHEN 2 THEN "USTO"
    WHEN 3 THEN "UMC"
    ELSE "UBMA"
  END,

  filiere: CASE i%5
    WHEN 0 THEN "Informatique"
    WHEN 1 THEN "Math"
    WHEN 2 THEN "Electro"
    WHEN 3 THEN "Telecom"
    ELSE "GL"
  END,

  annee: 1 + (i%5),
  ville: CASE i%5
    WHEN 0 THEN "Alger"
    WHEN 1 THEN "Boumerdes"
    WHEN 2 THEN "Oran"
    WHEN 3 THEN "Constantine"
    ELSE "Annaba"
  END
});


// ─────────────────────────────────────────────
// CONNAIT (graphe connexe)
// ─────────────────────────────────────────────

MATCH (a:Etudiant),(b:Etudiant)
WHERE a.id < b.id AND rand()<0.05
CREATE (a)-[:CONNAIT {depuis:2023}]->(b);


// ─────────────────────────────────────────────
// SUIT
// ─────────────────────────────────────────────

MATCH (e:Etudiant),(c:Cours)
WHERE rand()<0.4
CREATE (e)-[:SUIT {note:10+rand()*10}]->(c);


// ─────────────────────────────────────────────
// MAITRISE
// ─────────────────────────────────────────────

MATCH (e:Etudiant),(c:Competence)
WHERE rand()<0.3
CREATE (e)-[:MAITRISE {
  niveau: CASE
    WHEN rand()<0.3 THEN "Debutant"
    WHEN rand()<0.6 THEN "Inter"
    ELSE "Avance"
  END
}]->(c);


// ─────────────────────────────────────────────
// MEMBRE_DE
// ─────────────────────────────────────────────

MATCH (e:Etudiant),(c:Club)
WHERE rand()<0.2
CREATE (e)-[:MEMBRE_DE]->(c);


// ─────────────────────────────────────────────
// STAGE
// ─────────────────────────────────────────────

MATCH (e:Etudiant),(ent:Entreprise)
WHERE rand()<0.1
CREATE (e)-[:A_STAGE_CHEZ {annee:2025}]->(ent);
