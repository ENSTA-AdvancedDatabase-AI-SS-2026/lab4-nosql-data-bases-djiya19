
# TP4 — Neo4j UniConnect DZ

## 1. Modélisation
Graphe composé de :
- Etudiants
- Cours
- Compétences
- Clubs
- Entreprises

Relations :
CONNAIT, SUIT, MAITRISE, MEMBRE_DE, A_STAGE_CHEZ

---

## 2. Communautés (Louvain)

Les communautés détectées regroupent :
- même filière
- même université
- mêmes connexions sociales

Conclusion :
Le graphe reflète naturellement les groupes étudiants.

---

## 3. SQL vs Cypher

SQL :
- JOIN complexes
- difficile pour relations profondes

Cypher :
- intuitif
- navigation naturelle
- adapté aux graphes

---

## 4. Conclusion

Neo4j est idéal pour :
- réseaux sociaux
- recommandation
- analyse de communautés
