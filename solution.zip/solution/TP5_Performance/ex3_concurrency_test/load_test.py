
from concurrent.futures import ThreadPoolExecutor
import time

def task():
    time.sleep(0.01)

with ThreadPoolExecutor(max_workers=50) as ex:
    for _ in range(50):
        ex.submit(task)

print("Load test done")
