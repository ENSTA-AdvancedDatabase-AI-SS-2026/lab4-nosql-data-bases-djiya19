
from cassandra.cluster import Cluster
import time, random

cluster = Cluster(['127.0.0.1'])
session = cluster.connect()

session.execute("CREATE KEYSPACE IF NOT EXISTS tp WITH replication={'class':'SimpleStrategy','replication_factor':1}")
session.execute("USE tp")
session.execute("CREATE TABLE IF NOT EXISTS data (id int PRIMARY KEY, v double)")

N = 1000
start = time.time()
for i in range(N):
    session.execute("INSERT INTO data (id, v) VALUES (%s,%s)", (i, random.random()))
end = time.time()

print("Cassandra throughput:", N/(end-start))
