
from neo4j import GraphDatabase
import time, random

driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j","test"))

def insert(tx,i,v):
    tx.run("CREATE (:Node {id:$i, v:$v})", i=i, v=v)

N = 1000
start = time.time()
with driver.session() as session:
    for i in range(N):
        session.write_transaction(insert, i, random.random())
end = time.time()

print("Neo4j throughput:", N/(end-start))
