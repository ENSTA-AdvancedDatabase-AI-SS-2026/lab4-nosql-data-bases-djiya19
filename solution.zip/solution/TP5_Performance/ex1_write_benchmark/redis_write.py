
import redis, time, random

r = redis.Redis(host='localhost', port=6379)
N = 10000

start = time.time()
for i in range(N):
    r.set(i, str(random.random()))
end = time.time()

print("Redis throughput:", N/(end-start))
