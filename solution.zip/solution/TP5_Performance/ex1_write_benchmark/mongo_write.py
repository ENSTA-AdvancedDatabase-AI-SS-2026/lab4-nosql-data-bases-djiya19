
from pymongo import MongoClient
import time, random

c = MongoClient("mongodb://localhost:27017/")
db = c.tp
col = db.data

N = 10000
start = time.time()
for i in range(N):
    col.insert_one({"id": i, "v": random.random()})
end = time.time()

print("Mongo throughput:", N/(end-start))
