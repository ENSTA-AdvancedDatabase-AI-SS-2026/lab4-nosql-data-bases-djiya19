
# Final Decision

- Redis: cache
- MongoDB: general purpose
- Cassandra: big data
- Neo4j: graph
