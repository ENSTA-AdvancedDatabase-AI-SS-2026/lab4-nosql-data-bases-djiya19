
import matplotlib.pyplot as plt

dbs = ["Redis","MongoDB","Cassandra","Neo4j"]
vals = [100,80,120,60]

plt.bar(dbs, vals)
plt.title("Throughput comparison")
plt.show()
