# TP5 - NoSQL Benchmark

## How to run

### Write benchmark
python ex1_write_benchmark/redis_write.py

### Read benchmark
python ex2_read_benchmark/point_query.py

## Stack
- Redis
- MongoDB
- Cassandra
- Neo4j
