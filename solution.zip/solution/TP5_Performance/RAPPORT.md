# RAPPORT TP5 - NoSQL Benchmark

## 1. Introduction
Benchmark Redis, MongoDB, Cassandra, Neo4j

## 2. Ex1 Write Benchmark
| DB | Throughput | P95 |
|----|------------|-----|
| Redis | TODO | TODO |
| MongoDB | TODO | TODO |
| Cassandra | TODO | TODO |
| Neo4j | TODO | TODO |

## 3. Ex2 Read Benchmark
- Point query fastest: Redis
- Range query best: Cassandra
- Complex query best: Neo4j

## 4. Ex3 Concurrency
- Cassandra scales best under load

## 5. Conclusion
Each DB has a specific use case
