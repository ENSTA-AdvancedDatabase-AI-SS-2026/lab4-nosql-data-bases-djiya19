
print("Range query test")
