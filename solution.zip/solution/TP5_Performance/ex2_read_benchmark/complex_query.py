
print("Complex query test")
