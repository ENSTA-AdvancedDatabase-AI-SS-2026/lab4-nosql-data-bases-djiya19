
# pseudo benchmark
print("Point query test")
