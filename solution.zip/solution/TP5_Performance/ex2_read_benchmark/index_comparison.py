
print("Index comparison before/after")
